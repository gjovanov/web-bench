module.exports = {
  query: require('./query'),
  header: require('./header'),
  param: require('./param'),
  body: require('./body'),
  pipe: require('./pipe')
}
