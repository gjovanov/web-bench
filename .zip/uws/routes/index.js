module.exports = [
  ...require('./ping/ping-routes')
]
