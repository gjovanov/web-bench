public class PongResult {
    public string Result {get; set; }
}